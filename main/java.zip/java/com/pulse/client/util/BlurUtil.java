package com.pulse.client.util;

import net.minecraft.client.gui.DrawContext;

/**
 * Rounded-rect drawing utility.
 * Compatible with Minecraft 1.21.x — uses only DrawContext.fill() which is stable.
 */
public class BlurUtil {

    // ─── full rounded rect ─────────────────────────────────────────────── //

    public static void drawRoundedRect(DrawContext ctx, float x, float y, float w, float h, float r, int color) {
        int ix = (int)x, iy = (int)y, iw = (int)w, ih = (int)h;
        int ir = (int) Math.min(r, Math.min(iw, ih) / 2f);
        if (iw <= 0 || ih <= 0) return;

        ctx.fill(ix + ir, iy,        ix + iw - ir, iy + ih,      color);
        ctx.fill(ix,      iy + ir,   ix + ir,      iy + ih - ir, color);
        ctx.fill(ix + iw - ir, iy + ir, ix + iw,  iy + ih - ir, color);

        fillCorner(ctx, ix + ir,      iy + ir,      ir, color, 2);
        fillCorner(ctx, ix + iw - ir, iy + ir,      ir, color, 1);
        fillCorner(ctx, ix + ir,      iy + ih - ir, ir, color, 3);
        fillCorner(ctx, ix + iw - ir, iy + ih - ir, ir, color, 0);
    }

    // ─── top-only rounded rect (for panel headers) ─────────────────────── //

    public static void drawRoundedRectTop(DrawContext ctx, float x, float y, float w, float h, float r, int color) {
        int ix = (int)x, iy = (int)y, iw = (int)w, ih = (int)h;
        int ir = (int) Math.min(r, Math.min(iw, ih) / 2f);
        if (iw <= 0 || ih <= 0) return;

        ctx.fill(ix + ir, iy,      ix + iw - ir, iy + ih, color);
        ctx.fill(ix,      iy + ir, ix + ir,      iy + ih, color);
        ctx.fill(ix + iw - ir, iy + ir, ix + iw, iy + ih, color);

        fillCorner(ctx, ix + ir,      iy + ir, ir, color, 2);
        fillCorner(ctx, ix + iw - ir, iy + ir, ir, color, 1);
    }

    // ─── 1px border outline ────────────────────────────────────────────── //

    public static void drawRoundedRectOutline(DrawContext ctx, float x, float y, float w, float h, float r, float lw, int color) {
        int ix = (int)x, iy = (int)y, iw = (int)w, ih = (int)h;
        int ilw = Math.max(1, (int)lw);
        int ir  = (int) Math.min(r, Math.min(iw, ih) / 2f);

        ctx.fill(ix + ir, iy,             ix + iw - ir, iy + ilw,            color); // top
        ctx.fill(ix + ir, iy + ih - ilw,  ix + iw - ir, iy + ih,             color); // bottom
        ctx.fill(ix,      iy + ir,        ix + ilw,      iy + ih - ir,        color); // left
        ctx.fill(ix + iw - ilw, iy + ir,  ix + iw,       iy + ih - ir,        color); // right
    }

    // ─── vertical gradient (top-to-bottom, no z param needed) ─────────── //

    public static void drawGradientRect(DrawContext ctx, int x, int y, int w, int h, int colorTop, int colorBottom) {
        // fillGradient(x1, y1, x2, y2, colorStart, colorEnd) — 6-param version stable in 1.21.x
        ctx.fillGradient(x, y, x + w, y + h, colorTop, colorBottom);
    }

    // ─── private: quarter-circle corner fill ───────────────────────────── //

    /** quadrant: 0=bottom-right  1=bottom-left  2=top-left  3=top-right */
    private static void fillCorner(DrawContext ctx, int cx, int cy, int r, int color, int quad) {
        for (int px = -r; px <= r; px++) {
            for (int py = -r; py <= r; py++) {
                if (px * px + py * py > r * r) continue;
                boolean ok = switch (quad) {
                    case 0 -> px >= 0 && py >= 0;
                    case 1 -> px <= 0 && py >= 0;
                    case 2 -> px <= 0 && py <= 0;
                    case 3 -> px >= 0 && py <= 0;
                    default -> false;
                };
                if (ok) ctx.fill(cx + px, cy + py, cx + px + 1, cy + py + 1, color);
            }
        }
    }
}

package com.pulse.client.event;

import com.pulse.client.PulseClient;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class EventBus {

    private final Map<Class<?>, List<ListenerEntry>> listenerMap = new ConcurrentHashMap<>();

    public void register(IListener listener) {
        for (Method method : listener.getClass().getDeclaredMethods()) {
            if (!method.isAnnotationPresent(EventHandler.class)) continue;
            if (method.getParameterCount() != 1) continue;
            Class<?> eventClass = method.getParameterTypes()[0];
            method.setAccessible(true);
            listenerMap.computeIfAbsent(eventClass, k -> new CopyOnWriteArrayList<>())
                    .add(new ListenerEntry(listener, method));
        }
    }

    public void unregister(IListener listener) {
        for (List<ListenerEntry> entries : listenerMap.values()) {
            entries.removeIf(e -> e.listener() == listener);
        }
    }

    public void post(Object event) {
        List<ListenerEntry> entries = listenerMap.get(event.getClass());
        if (entries == null) return;
        for (ListenerEntry entry : entries) {
            try {
                entry.method().invoke(entry.listener(), event);
            } catch (Exception e) {
                PulseClient.LOGGER.error("EventBus dispatch error", e);
            }
        }
    }

    private record ListenerEntry(IListener listener, Method method) {}
}

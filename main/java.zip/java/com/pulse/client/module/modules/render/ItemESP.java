package com.pulse.client.module.modules.render;

import com.pulse.client.event.EventHandler;
import com.pulse.client.event.events.EventRender2D;
import com.pulse.client.module.Category;
import com.pulse.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.Window;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;

public class ItemESP extends Module {

    public ItemESP() {
        super("ItemESP", "Показывает названия предметов на земле", Category.RENDER);
    }

    @EventHandler
    public void onRender2D(EventRender2D event) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null || mc.gameRenderer == null) return;

        DrawContext ctx = event.getDrawContext();
        Window window = mc.getWindow();
        Camera camera = mc.gameRenderer.getCamera();
        Vec3d camPos = camera.getPos();

        float pitch = (float) Math.toRadians(camera.getPitch());
        float yaw   = (float) Math.toRadians(camera.getYaw() + 180.0f);
        Matrix4f viewMatrix = new Matrix4f().rotateX(pitch).rotateY(yaw);
        Matrix4f projMatrix = mc.gameRenderer.getBasicProjectionMatrix(
                mc.options.getFov().getValue()
        );

        for (ItemEntity itemEntity : mc.world.getEntitiesByClass(
                ItemEntity.class,
                mc.player.getBoundingBox().expand(48),
                e -> true)) {

            ItemStack stack = itemEntity.getStack();
            if (stack.isEmpty()) continue;

            Vec3d pos = itemEntity.getLerpedPos(event.getTickDelta())
                    .add(0, itemEntity.getHeight() + 0.35, 0);

            float rx = (float)(pos.x - camPos.x);
            float ry = (float)(pos.y - camPos.y);
            float rz = (float)(pos.z - camPos.z);

            Vector4f vec = new Vector4f(rx, ry, rz, 1.0f);
            viewMatrix.transform(vec);
            projMatrix.transform(vec);

            if (vec.w <= 0) continue;

            float ndcX = vec.x / vec.w;
            float ndcY = vec.y / vec.w;

            if (ndcX < -1.1f || ndcX > 1.1f) continue;
            if (ndcY < -1.1f || ndcY > 1.1f) continue;

            int screenX = (int)((ndcX + 1.0f) / 2.0f * window.getScaledWidth());
            int screenY = (int)((1.0f - ndcY) / 2.0f * window.getScaledHeight());

            // Разделяем название и количество для разной покраски
            String nameText = stack.getName().getString();
            String countText = stack.getCount() > 1 ? " x" + stack.getCount() : "";

            int nameWidth = mc.textRenderer.getWidth(nameText);
            int countWidth = countText.isEmpty() ? 0 : mc.textRenderer.getWidth(countText);
            int totalWidth = nameWidth + countWidth;
            int textHeight = mc.textRenderer.fontHeight;

            // Вычисляем координаты для центрирования текста на экране без матриц
            int x = screenX - totalWidth / 2;
            int y = screenY - textHeight / 2;

            // Темный полупрозрачный фон (0x90 = ~56% непрозрачности, как на 2 скрине)
            ctx.fill(x - 2, y - 1, x + totalWidth + 2, y + textHeight + 1, 0x90000000);

            // Отрисовываем название предмета (Белым цветом)
            ctx.drawTextWithShadow(mc.textRenderer, nameText, x, y, 0xFFFFFFFF);

            // Если предметов больше 1, отрисовываем количество (Красным цветом)
            if (!countText.isEmpty()) {
                // Смещаем координату X на ширину названия предмета
                ctx.drawTextWithShadow(mc.textRenderer, countText, x + nameWidth, y, 0xFFFF5555);
            }
        }
    }
}
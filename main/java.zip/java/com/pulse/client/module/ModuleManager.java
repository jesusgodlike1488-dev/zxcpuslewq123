package com.pulse.client.module;

import com.pulse.client.module.modules.combat.KillAura;
import com.pulse.client.module.modules.combat.Reach;
import com.pulse.client.module.modules.combat.TriggerBot;
import com.pulse.client.module.modules.movement.NoSlow;
import com.pulse.client.module.modules.movement.Sprint;
import com.pulse.client.module.modules.movement.Step;
import com.pulse.client.module.modules.player.AntiAFK;
import com.pulse.client.module.modules.player.AutoTotem;
import com.pulse.client.module.modules.player.ChestStealer;
import com.pulse.client.module.modules.render.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // Movement
        register(new Sprint());
        register(new NoSlow());
        register(new Step());

        // Combat
        register(new KillAura());
        register(new Reach());
        register(new TriggerBot());

        // Render
        register(new ESP());
        register(new NoRender());
        register(new ItemESP());
        register(new TargetHud());
        register(new Fullbright());
        register(new Tracers());   // BUG FIX: Tracers existed but was never registered

        // Player
        register(new AutoTotem());
        register(new ChestStealer());
        register(new AntiAFK());
    }

    private void register(Module module) { modules.add(module); }

    public Module getModule(String name) {
        return modules.stream()
            .filter(m -> m.getName().equalsIgnoreCase(name))
            .findFirst().orElse(null);
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T getModule(Class<T> clazz) {
        return modules.stream()
            .filter(m -> m.getClass() == clazz)
            .map(m -> (T) m)
            .findFirst().orElse(null);
    }

    public List<Module>  getModules()                    { return modules; }
    public List<Module>  getModulesByCategory(Category c){ return modules.stream().filter(m -> m.getCategory() == c).collect(Collectors.toList()); }
    public List<Module>  getEnabledModules()             { return modules.stream().filter(Module::isEnabled).collect(Collectors.toList()); }
}
